The execution of the code is documented in the notebook. 

In order to run the notebook, you will need the following files: 


(i) forex2017_top5.txt: contains FOREX data from January 2017 to July 27th 2017. 


(ii) Caramuta_capstone_training_FINAL.py: contains the code that is used for training the Q-learning agent. This code will output the Q funtion that is going to be used during the testing. 


(iii) Caramuta_capstone_testing_FINAL.py : contains the code that is used for testing the Q-learning agent and that is used for running the agent that makes random choices


This project uses python and basic libraries like numpy and pandas.

